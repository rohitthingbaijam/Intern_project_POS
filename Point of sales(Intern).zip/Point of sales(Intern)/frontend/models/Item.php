<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "item".
 *
 * @property int $id
 * @property string $item_name
 * @property double $rate
 * @property string $material
 * @property string $created_date
 * @property string $created_by
 *
 * @property SalesItem[] $salesItems
 * @property Stock[] $stocks
 */
class Item extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'item';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['item_name', 'rate', 'material', 'created_date', 'created_by'], 'required'],
            [['rate','created_by'], 'number'],
            [['created_date'], 'safe'],
            [['item_name', 'material'], 'string', 'max' => 50],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'item_name' => 'Item Name',
            'rate' => 'Rate',
            'material' => 'Material',
            'created_date' => 'Created Date',
            'created_by' => 'Created By',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSalesItems()
    {
        return $this->hasMany(SalesItem::className(), ['item_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getStocks()
    {
        return $this->hasMany(Stock::className(), ['item_id' => 'id']);
    }
}
