<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "sales".
 *
 * @property int $id
 * @property double $total
 * @property double $amount
 * @property double $discount
 * @property string $created_date
 * @property int $created_by
 * @property double $tax
 *
 * @property SalesItem[] $salesItems
 */
class Sales extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'sales';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['total', 'amount', 'created_date', 'created_by', 'tax'], 'required'],
            [['total', 'amount', 'discount', 'tax'], 'number'],
            [['created_date'], 'safe'],
            [['created_by'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'total' => 'Total',
            'amount' => 'Amount',
            'discount' => 'Discount',
            'created_date' => 'Created Date',
            'created_by' => 'Created By',
            'tax' => 'Tax',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSalesItems()
    {
        return $this->hasMany(SalesItem::className(), ['sales_id' => 'id']);
    }
}
