<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>

<div class="site-index">

    <div class="jumbotron">
          <p class="text-success text-lg"><h1>SUNITA LADIES COLLECTION</h1></p> 
		

        <p><a class="btn btn-sm btn-primary btn-block"  href="http://localhost/pos2/frontend/web/index.php?r=item%2Findex">Insert items</a></p>
		<p><a class="btn btn-sm btn-primary btn-block"  href="http://localhost/pos2/frontend/web/index.php?r=stock%2Findex">Stock</a></p>
		<p><a class="btn btn-sm btn-primary btn-block"  href="http://localhost/pos2/frontend/web/index.php?r=sales%2Findex">Sales</a></p>
		<p><a class="btn btn-sm btn-primary btn-block"  href="http://localhost/pos2/frontend/web/index.php?r=sales_item%2Findex">Sales item</a></p>
	
	
	</div>


 
</div>




		