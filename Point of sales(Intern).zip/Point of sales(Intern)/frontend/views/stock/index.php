<?php

use yii\helpers\Html;
use yii\grid\GridView;
use kartik\select2\Select2;
use app\models\Item;
use yii\helpers\ArrayHelper;


/* @var $this yii\web\View */
/* @var $searchModel app\models\StockSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Stocks';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="stock-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Html::a('Create Stock', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
			[
				'attribute'=>'item_id',
				'value'=>'item.item_name',
				
				'filter' => Select2::widget([
							'model' => $searchModel,
							'attribute' => 'item_id',
							'data' => ArrayHelper::map(\app\models\Item::find()->asArray()->all(), 'id', 'item_name'),
							'theme' => Select2::THEME_BOOTSTRAP,
							'options' => [
							'placeholder' => 'Name of the item',
							],
							'pluginOptions' => [ 
								'allowClear' => true
							], 
						]),
						],
            //'id',
            'quantity',
          
            'status',
            'created_date',
            //'created_by',

            ['class' => 'yii\grid\ActionColumn',
			'template'=>'{view},{update}'],
        ],
    ]); ?>
</div>
