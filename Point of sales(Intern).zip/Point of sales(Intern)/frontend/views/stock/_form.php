<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use kartik\select2\Select2;

/* @var $this yii\web\View */
/* @var $model app\models\Stock */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="stock-form">

    <?php $form = ActiveForm::begin(); ?>
	
	<input type="hidden" id="phpqty" name="phpqty" value="<?php echo $model->quantity;?>" />
    <!--<?php $dataItem=ArrayHelper::map(\app\models\Item::find()->asArray()->all(), 'id', 'item_name');
	
	echo $form->field($model, 'item_id')->dropDownList($dataItem, 
	         ['prompt'=>'-Choose an Item-',
			  ]);  ?>-->
			
	<?= $form->field($model, 'item_id')->widget(Select2::classname(), [
    'data' => ArrayHelper::map(\app\models\Item::find()->asArray()->all(), 'id', 'item_name'),
    'language' => 'de',
    'options' => ['placeholder' => 'Select a item ...'],
    'pluginOptions' => [ 
        'allowClear' => true
    ],
]);?>
	<?= $form->field($model, 'quantity')->textInput([
	'onchange'=>'var phpqty = $("#phpqty").val();
			var curqty =$("#stock-quantity").val();
			if(curqty<phpqty){
				alert("Quantity cannot be less than already existing quantity which is "+phpqty);
				$("#stock-quantity").val("");
				}
				'])?>
		


    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-success',
		'onclick'=>'
					var phpqty =$("#phpqty").val();
					var curqty =$("#stock-quantity").val();
					if(curqty<phpqty){
						alert("Quantity cannot be less than  already exixting quantity which is "+phpqty");
						$("#stock-quantity").val("");
					}
			']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
